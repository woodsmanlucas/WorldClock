import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './index.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'WorldClock';
  selectedcity = "london"
}
