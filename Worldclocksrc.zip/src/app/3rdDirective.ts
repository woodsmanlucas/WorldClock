import { Component } from '@angular/core';

// Define second directive.
@Component({
    // Selector uses lower case with hyphens.
    selector: 'third',
    templateUrl: './3rd.html',
})
export class third {
}
